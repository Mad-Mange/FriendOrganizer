﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Zza.Data
{
    public class OrderStatus
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
